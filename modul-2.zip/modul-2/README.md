Újabb, kiegészített, frissített kódok a GitHub profilomnál találhatók!

https://github.com/siposm